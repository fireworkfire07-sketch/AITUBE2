import os
import json
import glob
from pathlib import Path
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# ── OAuth (aitube-quantum'daki ile aynı mantık, farklı secret prefix) ────────
def get_youtube():
    creds = Credentials(
        token=None,
        refresh_token=os.environ["YT_SOL_REFRESH_TOKEN"],
        client_id=os.environ["YT_SOL_CLIENT_ID"],
        client_secret=os.environ["YT_SOL_CLIENT_SECRET"],
        token_uri="https://oauth2.googleapis.com/token",
        scopes=["https://www.googleapis.com/auth/youtube.upload"],
    )
    return build("youtube", "v3", credentials=creds)

def upload():
    # En son render edilmiş videoyu bul
    videos = sorted(glob.glob("output/*/final.mp4"))
    if not videos:
        print("No video found to upload.")
        return

    video_path = videos[-1]
    work_dir   = Path(video_path).parent
    meta_path  = work_dir / "meta.json"

    meta = json.loads(meta_path.read_text())

    yt = get_youtube()

    body = {
        "snippet": {
            "title":       meta["title"],
            "description": meta["description"],
            "tags":        meta["tags"].split(","),
            "categoryId":  "27",   # Education
            "defaultLanguage": "en",
        },
        "status": {
            "privacyStatus":           "public",
            "selfDeclaredMadeForKids": False,
            # 2026 zorunluluğu: AI içerik açıklaması
            "containsSyntheticMedia":  True,
        },
    }

    media = MediaFileUpload(
        video_path,
        mimetype="video/mp4",
        resumable=True,
        chunksize=10 * 1024 * 1024,  # 10 MB chunk
    )

    print(f"⬆️  Uploading: {meta['title']}")
    request = yt.videos().insert(part="snippet,status", body=body, media_body=media)

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            pct = int(status.progress() * 100)
            print(f"   {pct}%")

    vid_id = response["id"]
    print(f"✅ Uploaded → https://youtu.be/{vid_id}")

if __name__ == "__main__":
    upload()
