# Solomon Wealth — AI Otomatik YouTube Kanalı

Günlük otomatik video: **Groq → edge-tts → Pollinations → ffmpeg → YouTube**

---

## Klasör Yapısı

```
solomon_wealth/
├── generate_video.py      # ana pipeline
├── upload_youtube.py      # YouTube yükleme
├── topics.txt             # işlenecek konular (her satır = 1 video)
├── islenmis.txt           # işlenen konular (otomatik güncellenir)
├── assets/
│   ├── bgmusic.mp3        # opsiyonel arka plan müziği
│   └── Cinzel-Regular.ttf # altyazı fontu (indir, buraya koy)
├── output/                # üretilen videolar (gitignore)
└── .github/
    └── workflows/
        └── solomon_daily.yml
```

---

## Kurulum (1 kez)

### 1. GitHub Secrets — YENİ bir kanal, YENİ secret isimleri

Repo → Settings → Secrets → Actions → New repository secret:

| Secret Adı              | Değer                                    |
|-------------------------|------------------------------------------|
| `GROQ_API_KEY`          | Groq API anahtarın                       |
| `YT_SOL_CLIENT_ID`      | Google OAuth client ID (bu kanala özel)  |
| `YT_SOL_CLIENT_SECRET`  | Google OAuth client secret               |
| `YT_SOL_REFRESH_TOKEN`  | Refresh token (aşağıda nasıl alınır)     |

> **Neden `YT_SOL_` prefix?** Diğer kanallarınla karışmasın (aitube-quantum'da `YT_`, `YT2_` vs). Her kanal kendi prefix'i.

### 2. YouTube OAuth Refresh Token Al

```bash
# Lokal bilgisayarda bir kez çalıştır
pip install google-auth-oauthlib

python - <<'EOF'
from google_auth_oauthlib.flow import InstalledAppFlow
flow = InstalledAppFlow.from_client_secrets_file(
    "client_secret.json",  # Google Cloud Console'dan indirdiğin dosya
    scopes=["https://www.googleapis.com/auth/youtube.upload"]
)
creds = flow.run_local_server(port=0)
print("REFRESH TOKEN:", creds.refresh_token)
EOF
```

Çıkan token'ı `YT_SOL_REFRESH_TOKEN` olarak kaydet.

### 3. Font (altyazı için)

Cinzel-Regular.ttf → Google Fonts'tan indir → `assets/` klasörüne koy.

Alternatif: `generate_video.py` içinde font adını değiştir.

### 4. Opsiyonel: Arka Plan Müziği

Royalty-free bariton/ambient bir parça (önerim: Pixabay veya Freepd.com) →  
`assets/bgmusic.mp3` olarak kaydet. Yoksa sessiz geçer, sorun olmaz.

---

## Çalıştırma

### Elle (test için):
```bash
pip install groq edge-tts requests faster-whisper
python generate_video.py
```

### Otomatik: Her gün 08:00 UTC (11:00 TR) GitHub Actions çalıştırır.

Elle tetiklemek için: Repo → Actions → Solomon Wealth Daily → Run workflow.

---

## Konu Ekleme

`topics.txt` dosyasına yeni satır ekle, commit et — otomatik pick up edilir.  
`islenmis.txt`'de olan konular atlanır (sonsuz döngü yok).

---

## 2026 YouTube Uyumu

- `containsSyntheticMedia: True` → upload sırasında otomatik işaretlenir.
- Telif: senaryo özgün, scripture birebir alıntı yok, rakip kanalın içeriği kopyalanmıyor.
- Finansal garanti verilmiyor (sistem promptu engelliyor).

---

## Pipeline Özeti

```
topics.txt
   ↓ pick_topic()
Groq llama-3.3-70b → JSON (title, script, image_prompts, description...)
   ↓
edge-tts ChristopherNeural → voice.mp3
   ↓
Pollinations (Flux) × 10 → images/
   ↓
faster-whisper → subtitles.ass (kelime-kelime karaoke)
   ↓
ffmpeg → Ken Burns + altyazı + ses normalizasyon → final.mp4
   ↓
YouTube Data API v3 → upload (public, Education, AI disclosed)
   ↓
islenmis.txt güncelle → commit
```
